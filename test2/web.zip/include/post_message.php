<?php  

      /*
 
if(isset($_POST['submit'])){ 
    
        $msg_Name =  $_POST['message_Name'];
        $msg_Email =  $_POST['message_Email'];
        $msg_Message =   $_POST['message_Message'];
    
 */
                  
    
     
                                       
   echo '<script>alert("Message sent we will get back to you!"); window.location.href = "../contact.html"</script>';  
                              
    

 
 /*
     } else{
             
      echo '<script>';
   echo 'window.location.href = "../404.php"</script>'; 
    exit();
 
    
 } 
*/
 
            
?>


